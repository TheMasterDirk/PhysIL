============================================ ABOUT
Pok�mon Gaia
Base ROM: 	BPRE FireRed
Language: 	English
Version: 	0.2
Released:	11/05/2015
Thread:		http://www.pokecommunity.com/showthread.php?t=326118

To play, download a FireRed ROM and apply the .UPS patch to the .GBA file using NUPS.

Version 0.2 ends in Telmurk City.

Saves from v0.1.1 are NOT compatible with v0.2.
This is unfortunate but ultimately unavoidable due to how much has been changed, updated and improved.

============================================ BUGS
Dragon Tail may still switch out Fairy-types;
The stat change animations for Acupressure are not always the correct colours;
The elevator animation does not play when going downwards;
The player indicator in the Town Map is in the wrong position in most "dungeon" maps;
The Battle Marsh's win streak counter does not increment past 17 turns;
Brine is not absorbed by Water Absorb;
Gyro Ball and Electro Ball do not display the "effectiveness" string.